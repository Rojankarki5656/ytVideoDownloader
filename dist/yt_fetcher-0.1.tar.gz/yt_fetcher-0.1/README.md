# yt-downloader-new

A command-line tool to download YouTube videos or audio using yt-dlp.

## Installation

```bash
pip install yt-downloader-new


```usage
yt-download-new https://youtube.com/watch?v=xxxx
yt-download-new https://youtube.com/watch?v=xxxx --audio
